<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Quiz Result</title>
</head>
<body>
    <h1>Quiz Result</h1>
    <form action="update_result.php" method="post">
        <label for="student_id">Student ID:</label>
        <input type="text" id="student_id" name="student_id" required><br><br>
        
        <label for="quiz_id">Quiz ID:</label>
        <input type="text" id="quiz_id" name="quiz_id" required><br><br>
        
        <label for="questions_attempted">Number of Questions Attempted:</label>
        <input type="number" id="questions_attempted" name="questions_attempted" required><br><br>
        
        <label for="score">Score:</label>
        <input type="number" id="score" name="score" required><br><br>
        
        <input type="submit" value="Update Result">
    </form>
</body>
</html>
